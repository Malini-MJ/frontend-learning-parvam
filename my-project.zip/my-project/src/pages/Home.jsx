export default function home() {
  return (
   <div className="container" style={{ marginBottom: "1000x" }}>
      <h2>Welcome to ShopStyle</h2>
      {/* Your cards and homepage content here */}
    </div>
  );
}
