
export default function Collections() {
  return (
   <div className="container" style={{ marginBottom: "1000x" }}>
  <h2>Collections Page</h2>
  <p>This is where your collections will go.</p>
</div>

  );
}
