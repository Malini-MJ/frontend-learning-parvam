import React from "react";
import { Routes, Route, Link } from "react-router-dom";
import Collections from "./pages/Collections";
import Home from "./pages/Home";
import card1Image from "./assets/card1.jpg"; 
import card2Image from "./assets/card2.jpg"; 
import card3Image from "./assets/card3.jpg"; 
import card4Image from "./assets/card4.jpg"; 
import card5Image from "./assets/card5.jpg"; 
import card6Image from "./assets/card6.jpg"; 
import card7Image from "./assets/card7.jpg"; 
import card8Image from "./assets/card8.jpg"; 
import card9Image from "./assets/card9.jpg"; 
import card10Image from "./assets/card10.jpg"; 
import card11Image from "./assets/card11.jpg"; 
import card12Image from "./assets/card12.jpg"; 

import jake1Image from "./assets/jake1.jpg"; 
import jake2Image from "./assets/jake2.jpg"; 
import jake3Image from "./assets/jake3.jpg"; 
import jake4Image from "./assets/jake4.jpg"; 
import jake5Image from "./assets/jake5.jpg"; 
import jake6Image from "./assets/jake6.jpg"; 




import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';



export default function App() {
  const cards = [
  {
    id: 1,
    title: "Card One",
    text: "This is the first card.",
    image: "https://via.placeholder.com/300x200?text=Card+1",
    link: "#"
  },
  {
    id: 2,
    title: "Card Two",
    text: "Second card with different content.",
    image: "https://via.placeholder.com/300x200?text=Card+2",
    link: "#"
  },
  {
    id: 3,
    title: "Card Three",
    text: "Third card says hello!",
    image: "https://via.placeholder.com/300x200?text=Card+3",
    link: "#"
  }
];

  return (
    <>
      {/* Navbar */}
      <nav style={{ backgroundColor: "#7593af" }} className="navbar navbar-expand-lg">
        <div className="container-fluid">
          <Link className="navbar-brand" to="/">ShopStyle</Link>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
            <span className="navbar-toggler-icon"></span>
          </button>

          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul className="navbar-nav me-auto mb-2 mb-lg-0">
              <li className="nav-item">
                <Link className="nav-link active" to="/">Home</Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link active" to="/Collections">Collections</Link>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="#">New</a>
              </li>
              <li className="nav-item">
                <a className="nav-link active" href="#">Category</a>
              </li>

              <li className="nav-item dropdown">
                <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">Products</a>
                <ul className="dropdown-menu">
                  <li><a className="dropdown-item" href="#">Women</a></li>
                  <li><a className="dropdown-item" href="#">Dresses</a></li>
                  <li><a className="dropdown-item" href="#">Men</a></li>
                  <li><a className="dropdown-item" href="#">Shirts</a></li>
                  <li><a className="dropdown-item" href="#">Bottoms</a></li>
                  <li><a className="dropdown-item" href="#">ActiveWear</a></li>
                  <li><a className="dropdown-item" href="#">Jewellery</a></li>
                  <li><a className="dropdown-item" href="#">Denims Women</a></li>
                  <li><a className="dropdown-item" href="#">Denims Men</a></li>
                  <li><a className="dropdown-item" href="#">Tops & Blouses</a></li>
                  <li><a className="dropdown-item" href="#">Trending</a></li>
                  <li><hr className="dropdown-divider" /></li>
                  <li><a className="dropdown-item" href="#">Accessories</a></li>
                </ul>
              </li>
              <li className="nav-item">
                <a className="nav-link disabled" href="#">Fresh Fits</a>
              </li>
            </ul>

            <form className="d-flex" role="search">
              <input className="form-control me-2" type="search" placeholder="Search" />
              <button className="btn btn-outline-light me-2" type="submit">Search</button>
              <button className="btn btn-outline-light" type="button">My Cart 🛒</button>
            </form>
          </div>
        </div>
      </nav>

      {/* Routes */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/collections" element={<Collections />} />
      </Routes>

      {/* Rest of the page content, modals, cards, etc. */}
      {/* Consider breaking them into components to keep App.jsx clean */}

      {/* Example: Suggestions Modal */}
      <div className="modal fade" id="messageModal" tabIndex="-1" aria-labelledby="messageModalLabel" aria-hidden="true">
        <div className="modal-dialog">
          <div className="modal-content">
            <div className="modal-header">
              <h1 className="modal-title fs-5" id="messageModalLabel">User Details</h1>
              <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div className="modal-body">
              <form>
                <div className="mb-3">
                  <label htmlFor="name" className="col-form-label">Name:</label>
                  <input type="text" className="form-control" id="name" />
                </div>
                <div className="mb-3">
                  <label htmlFor="phone" className="col-form-label">Phone No:</label>
                  <input type="tel" className="form-control" id="phone" />
                </div>
                <div className="mb-3">
                  <label htmlFor="email" className="col-form-label">Email:</label>
                  <input type="email" className="form-control" id="email" />
                </div>
              </form>
            </div>
            <div className="modal-footer">
              <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              <button type="button" className="btn btn-primary">Submit</button>
            </div>
          </div>
        </div>
      </div>

      <div className="container text-center mt-4">
        <button type="button" className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#messageModal">
          Give Suggestions
        </button>
      </div>

{/* Cards */}
      <div className="container mt-5">
  <div className="row">
    <div className="col-md-4">
      <div className="card">
  <img src={card1Image} className="card-img-top" alt="Card 1" />  
        <div className="card-body">
          <h5 className="card-title">old money</h5>
          <p className="card-text">set of striped shirt and brown pant</p>
          <a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>

        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card2Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">denim set</h5>
          <p className="card-text">denim top and pants.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card3Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">old money</h5>
          <p className="card-text">halter top beige pants.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div className="container mt-5">
  <div className="row">
    <div className="col-md-4">
      <div className="card">
  <img src={card4Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">turtle neck</h5>
          <p className="card-text">sleveless beige top .</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card5Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">sweater</h5>
          <p className="card-text">This is the second card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card6Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">beige sweater</h5>
          <p className="card-text">This is the third card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div className="container mt-5">
  <div className="row">
    <div className="col-md-4">
      <div className="card">
  <img src={card7Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">black top</h5>
          <p className="card-text">This is the first card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card8Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">brown top</h5>
          <p className="card-text">This is the second card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card9Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">frock</h5>
          <p className="card-text">This is the third card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div className="container mt-5">
  <div className="row">
    <div className="col-md-4">
      <div className="card">
  <img src={card10Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">top</h5>
          <p className="card-text">This is the first card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card11Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">casuala</h5>
          <p className="card-text">This is the second card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>

    <div className="col-md-4">
      <div className="card">
  <img src={card12Image} className="card-img-top" alt="Card 2" />  
        <div className="card-body">
          <h5 className="card-title">pink set</h5>
          <p className="card-text">This is the third card’s content.</p>
<a href="#" className="btn btn-primary me-2">add to cart</a>
                    <a href="#" className="btn btn-primary">buy now</a>
        </div>
      </div>
    </div>
  </div>
</div>
<div className="container mt-5">
  {/* Section Title */}
  <h4 className="mb-3">For You</h4>

  {/* Separator Line */}
  <hr style={{ borderTop: "2px solid #ccc" }} />

  {/* Content Below the Line */}
  <div className="mt-4">
    {/* Add your cards, text, or other content here */}
    <p>This is your personalized content section.</p>
  </div>
</div>
<div className="card-group">
  <div className="card">
      <img src={jake1Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">dast fashion</h5>
      <p className="card-text">
        This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>

  <div className="card">
          <img src={jake2Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">mens wear</h5>
      <p className="card-text">
        This card has supporting text below as a natural lead-in to additional content.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>

  <div className="card">
         <img src={jake3Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">winter wear</h5>
      <p className="card-text">
        This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>
</div>
<div className="card-group">
  <div className="card">
          <img src={jake4Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">acessories</h5>
      <p className="card-text">
        This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>

  <div className="card">
          <img src={jake5Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">jwellery</h5>
      <p className="card-text">
        This card has supporting text below as a natural lead-in to additional content.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>

  <div className="card">
        <img src={jake6Image} className="card-img-top" alt="Card 1" />  

    <div className="card-body">
      <h5 className="card-title">t-shirts</h5>
      <p className="card-text">
        This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.
      </p>
    </div>
    <div className="card-footer">
      <small className="text-body-secondary">Last updated 3 mins ago</small>
    </div>
  </div>
</div>


<div className="container mt-5">
  <div className="row justify-content-center g-3">
    <div className="col-auto">
      <div className="dropdown">
        <button className="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown">
filter        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 1A</a></li>
          <li><a className="dropdown-item" href="#">Option 1B</a></li>
        </ul>
      </div>
    </div>

    <div className="col-auto">
      <div className="dropdown">
        <button  className="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
category        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 2A</a></li>
          <li><a className="dropdown-item" href="#">Option 2B</a></li>
        </ul>
      </div>
    </div>

    <div className="col-auto">
      <div className="dropdown">
        <button className="btn btn-success dropdown-toggle" type="button" data-bs-toggle="dropdown">
sort by        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 3A</a></li>
          <li><a className="dropdown-item" href="#">Option 3B</a></li>
        </ul>
      </div>
    </div>

    <div className="col-auto">
      <div className="dropdown">
        <button className="btn btn-danger dropdown-toggle" type="button" data-bs-toggle="dropdown">
gender        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 4A</a></li>
          <li><a className="dropdown-item" href="#">Option 4B</a></li>
        </ul>
      </div>
    </div>

    <div className="col-auto">
      <div className="dropdown">
        <button className="btn btn-warning dropdown-toggle" type="button" data-bs-toggle="dropdown">
price        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 5A</a></li>
          <li><a className="dropdown-item" href="#">Option 5B</a></li>
        </ul>
      </div>
    </div>

    <div className="col-auto">
      <div className="dropdown">
        <button className="btn btn-info dropdown-toggle" type="button" data-bs-toggle="dropdown">
ocassion        </button>
        <ul className="dropdown-menu">
          <li><a className="dropdown-item" href="#">Option 6A</a></li>
          <li><a className="dropdown-item" href="#">Option 6B</a></li>
        </ul>
      </div>
    </div>
  </div>
</div>

      {/* Accordion */}
      <div className="accordion container-fluid mt-5" id="accordionPanelsStayOpen">
        {[1, 2, 3].map(num => (
          <div className="accordion-item" key={num}>
            <h2 className="accordion-header" id={`heading${num}`}>
              <button
                className={`accordion-button ${num !== 1 ? 'collapsed' : ''}`}
                type="button"
                data-bs-toggle="collapse"
                data-bs-target={`#collapse${num}`}
                aria-expanded={num === 1 ? "true" : "false"}
                aria-controls={`collapse${num}`}
              >
                Accordion Item #{num}
              </button>
            </h2>
            <div
              id={`collapse${num}`}
              className={`accordion-collapse collapse ${num === 1 ? 'show' : ''}`}
              aria-labelledby={`heading${num}`}
            >
              <div className="accordion-body">
                <strong>This is the item’s accordion body.</strong> You can modify this content.
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Login Form */}
      <div className="container-fluid mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6">
            <div className="card p-4 shadow-sm">
              <h4 className="mb-4 text-center">Login</h4>
              <form>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">Email address</label>
                  <input type="email" className="form-control" id="email" placeholder="Enter email" />
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">Password</label>
                  <input type="password" className="form-control" id="password" placeholder="Password" />
                </div>
                <button type="submit" className="btn btn-primary w-100">Login</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      <div className="container mt-5">
  <div className="row justify-content-center g-3">
    {[1, 2, 3, 4, 5, 6].map(num => (
      <div className="col-auto" key={num}>
        <div className="dropdown">
          <button
            className="btn btn-light"
            type="button"
            id={`dropdownMenu${num}`}
            data-bs-toggle="dropdown"
            aria-expanded="false"
          >
            <i className="bi bi-three-dots-vertical"></i>
          </button>
          <ul className="dropdown-menu" aria-labelledby={`dropdownMenu${num}`}>
            <li><a className="dropdown-item" href="#">Edit</a></li>
            <li><a className="dropdown-item" href="#">Share</a></li>
            <li><a className="dropdown-item" href="#">Delete</a></li>
          </ul>
        </div>
      </div>
    ))}
  </div>
</div>

    </>
  );
}

